﻿using _03BarracksFactory.Core.Commands;

namespace _03BarracksFactory.Core
{
    using System;
    using Contracts;

    class Engine : IRunnable
    {
        private IRepository repository;
        private IUnitFactory unitFactory;

        public Engine(IRepository repository, IUnitFactory unitFactory)
        {
            this.repository = repository;
            this.unitFactory = unitFactory;
        }

        public void Run()
        {
            while (true)
            {
                try
                {
                    string input = Console.ReadLine();
                    string[] data = input.Split();
                    string commandName = data[0];
                    string result = this.InterpredCommand(data, commandName);
                    Console.WriteLine(result);
                }
                catch (Exception e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }

        private string InterpredCommand(string[] data, string commandName)
        {
            string result = string.Empty;
            switch (commandName)
            {
                case "add":
                    result = new AddUnitCommand(data, repository, unitFactory).Execute();
                    break;
                case "report":
                    result = new ReportCommand(data, repository, unitFactory).Execute();
                    break;
                case "fight":
                    Environment.Exit(0);
                    break;
                case "retire":
                    result = new RetireCommand(data, repository, unitFactory).Execute();
                    break;
                default:
                    throw new InvalidOperationException("Invalid command!");
            }
            return result;
        }
    }
}
