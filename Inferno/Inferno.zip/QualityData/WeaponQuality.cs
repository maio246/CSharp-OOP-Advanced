﻿public enum WeaponQuality
{
    Common = 1,
    Uncommon = 2,
    Rare = 3,
    Epic = 5
}