﻿public interface IGem
{
    int Strength { get; }
    int Agility { get; }
    int Vitality { get; }
}