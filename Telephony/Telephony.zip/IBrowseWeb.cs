﻿public interface IBrowseWeb
{
    void Browse();
}

