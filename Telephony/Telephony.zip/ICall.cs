﻿public interface ICall
{
    void Call();
}

