﻿    public class ArrayFromT
    {
        public static void Main()
        {
        string[] asdf = ArrayCreator.Create(5, "Pesho");
        }
    }

