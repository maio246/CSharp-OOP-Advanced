﻿public interface ICar
{
    string Model { get; }
    string Driver { get; }
    string Breaks();
    string Gas();
}

